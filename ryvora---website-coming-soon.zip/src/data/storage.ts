import { Subscriber, SiteConfig } from '../types';

const STORAGE_KEY_SUBSCRIBERS = 'ryvora_subscribers_v1';
const STORAGE_KEY_CONFIG = 'ryvora_config_v1';

export const DEFAULT_CONFIG: SiteConfig = {
  instagramUrl: 'https://www.instagram.com/ryvora.pk?stkn=anR5eTQ4c3drb2sw',
  tiktokUrl: 'https://www.tiktok.com/@ryvora.pk',
  youtubeUrl: 'https://www.youtube.com/@ryvora',
  formspreeEndpoint: '', // Optional Formspree form ID/URL for instant inbox forwarding
  ownerEmailNotification: 'contact@ryvora.pk',
  brandName: 'RYVORA',
  launchDateEstimated: 'Fall 2026',
};

export function getStoredConfig(): SiteConfig {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_CONFIG);
    if (raw) {
      return { ...DEFAULT_CONFIG, ...JSON.parse(raw) };
    }
  } catch (e) {
    console.warn('Failed to load site config from storage', e);
  }
  return DEFAULT_CONFIG;
}

export function saveStoredConfig(config: Partial<SiteConfig>): SiteConfig {
  const updated = { ...getStoredConfig(), ...config };
  try {
    localStorage.setItem(STORAGE_KEY_CONFIG, JSON.stringify(updated));
  } catch (e) {
    console.warn('Failed to save site config', e);
  }
  return updated;
}

export function getSubscribers(): Subscriber[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_SUBSCRIBERS);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        return parsed;
      }
    }
  } catch (e) {
    console.warn('Failed to load subscribers from storage', e);
  }
  return [];
}

export async function addSubscriber(email: string): Promise<{ success: boolean; message: string; subscriber?: Subscriber }> {
  const trimmed = email.trim().toLowerCase();
  
  // Basic RFC email validation
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(trimmed)) {
    return { success: false, message: 'Please enter a valid email address.' };
  }

  const existing = getSubscribers();
  const alreadySubscribed = existing.find((s) => s.email.toLowerCase() === trimmed);
  if (alreadySubscribed) {
    return { 
      success: true, 
      message: "You're already on the exclusive launch list! We'll notify you first.",
      subscriber: alreadySubscribed 
    };
  }

  const newSub: Subscriber = {
    id: 'sub_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7),
    email: trimmed,
    createdAt: new Date().toISOString(),
    source: 'Coming Soon Website Form',
    notified: false,
  };

  const updated = [newSub, ...existing];
  try {
    localStorage.setItem(STORAGE_KEY_SUBSCRIBERS, JSON.stringify(updated));
  } catch (e) {
    console.warn('Failed to store subscriber locally', e);
  }

  // If a Formspree endpoint or webhook is configured, forward the submission in real-time
  const config = getStoredConfig();
  if (config.formspreeEndpoint && config.formspreeEndpoint.trim().startsWith('http')) {
    try {
      await fetch(config.formspreeEndpoint.trim(), {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        body: JSON.stringify({
          email: trimmed,
          source: 'RYVORA Coming Soon VIP List',
          timestamp: newSub.createdAt
        })
      });
    } catch (err) {
      console.warn('Could not forward to Formspree webhook', err);
      // Non-blocking: local storage is already saved safely!
    }
  }

  return { 
    success: true, 
    message: "Thank you for joining RYVORA. You'll be the first to receive priority access.",
    subscriber: newSub 
  };
}

export function removeSubscriber(id: string): Subscriber[] {
  const existing = getSubscribers();
  const filtered = existing.filter((s) => s.id !== id);
  try {
    localStorage.setItem(STORAGE_KEY_SUBSCRIBERS, JSON.stringify(filtered));
  } catch (e) {
    console.warn('Failed to remove subscriber', e);
  }
  return filtered;
}

export function markSubscribersNotified(): Subscriber[] {
  const existing = getSubscribers();
  const updated = existing.map(s => ({ ...s, notified: true }));
  try {
    localStorage.setItem(STORAGE_KEY_SUBSCRIBERS, JSON.stringify(updated));
  } catch (e) {
    console.warn('Failed to update subscribers', e);
  }
  return updated;
}

export function exportSubscribersToCSV(subscribers: Subscriber[]): void {
  if (subscribers.length === 0) return;
  const headers = ['Email', 'Signup Date', 'Status', 'Source'];
  const rows = subscribers.map((s) => [
    `"${s.email}"`,
    `"${new Date(s.createdAt).toLocaleString()}"`,
    `"${s.notified ? 'Notified of Launch' : 'Pending Launch'}"`,
    `"${s.source || 'Website'}"`
  ]);
  const csvContent = [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', `ryvora_vip_subscribers_${new Date().toISOString().slice(0, 10)}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
