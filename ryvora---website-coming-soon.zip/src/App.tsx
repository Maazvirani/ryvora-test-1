import { EmailSubscriptionForm } from './components/EmailSubscriptionForm';
import { InstagramLockup } from './components/SocialLinks';

const INSTAGRAM_URL = 'https://www.instagram.com/ryvora.pk?stkn=anR5eTQ4c3drb2sw';

export default function App() {
  return (
    <div className="min-h-screen w-full bg-[#EAE6DE] flex items-center justify-center p-0 sm:p-4 md:p-6 lg:p-8 font-sans-luxury text-[#111111] selection:bg-[#111111] selection:text-[#FAF8F5]">
      {/* 
        Editorial Poster Canvas Container 
        Scaled to authentic portrait fashion campaign aspect ratio (9:16 / 2:3) 
      */}
      <div
        id="ryvora-poster-canvas"
        className="relative w-full max-w-[620px] min-h-screen sm:min-h-[920px] sm:my-4 sm:rounded-none sm:shadow-2xl overflow-hidden flex flex-col justify-between p-6 sm:p-9 md:p-10 bg-[#F4F1EB]"
      >
        {/* Background Architectural Scene */}
        <div className="absolute inset-0 pointer-events-none z-0 overflow-hidden">
          <img
            src="/ryvora-bg.jpg"
            alt="Ryvora Architectural Setting"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover object-right-bottom sm:object-center select-none"
          />
          {/* Subtle editorial scrim ensuring crisp typographic contrast on the left */}
          <div className="absolute inset-0 bg-gradient-to-r from-[#F6F4EF]/95 via-[#F6F4EF]/75 to-transparent z-10 w-[75%] sm:w-[65%]" />
        </div>

        {/* Foreground Content Layer */}
        <div className="relative z-20 flex-1 flex flex-col justify-between">
          
          {/* ================= TOP SECTION ================= */}
          <header className="flex items-start justify-between w-full pt-1 sm:pt-2" id="poster-header">
            {/* Top-Left: RYVORA Logo + Slogan */}
            <div className="space-y-1.5" id="brand-header">
              <div className="flex items-center text-2xl sm:text-[28px] md:text-3xl tracking-[0.32em] font-serif-luxury font-normal text-[#111111] leading-none">
                <span>R Y V O R </span>
                <span className="font-sans font-light text-xl sm:text-2xl -ml-0.5 inline-block">Ʌ</span>
                <span className="text-[10px] font-sans font-normal ml-1 -mt-2.5">®</span>
              </div>
              <p className="text-[8px] sm:text-[9.5px] uppercase tracking-[0.28em] text-[#222222] font-semibold">
                DESIGNED THE WAY YOU LIVE.
              </p>
              {/* Horizontal rule accent under tagline */}
              <div className="w-9 sm:w-11 h-[1.5px] bg-[#111111] mt-3" aria-hidden="true" />
            </div>

            {/* Top-Right: STYLE LIVES FURTHER */}
            <div className="text-right space-y-0.5 pt-0.5" id="top-right-mantra">
              <p className="text-[8.5px] sm:text-[9.5px] uppercase tracking-[0.24em] text-[#222222] font-medium leading-tight">
                STYLE
              </p>
              <p className="text-[8.5px] sm:text-[9.5px] uppercase tracking-[0.24em] text-[#222222] font-medium leading-tight">
                LIVES
              </p>
              <p className="text-[8.5px] sm:text-[9.5px] uppercase tracking-[0.24em] text-[#222222] font-medium leading-tight">
                FURTHER
              </p>
              {/* Horizontal rule accent under mantra */}
              <div className="w-6 sm:w-7 h-[1.5px] bg-[#111111] ml-auto mt-2" aria-hidden="true" />
            </div>
          </header>

          {/* ================= MIDDLE SECTION ================= */}
          <main className="my-auto py-10 sm:py-14 space-y-7 sm:space-y-8 max-w-[380px] sm:max-w-[420px]" id="poster-main-content">
            {/* Display Headline: WEBSITE COMING SOON */}
            <div className="space-y-0.5">
              <p className="text-xs sm:text-[13px] tracking-[0.28em] font-serif-luxury text-[#222222] uppercase">
                WEBSITE
              </p>
              <h1 className="text-[52px] sm:text-[68px] md:text-[76px] font-serif-luxury font-normal tracking-tight text-[#111111] leading-[0.92]">
                <div>COMING</div>
                <div>SOON</div>
              </h1>
            </div>

            {/* Editorial Body Text */}
            <div className="space-y-3.5 pt-1">
              <p className="text-[10.5px] sm:text-[12px] uppercase tracking-[0.22em] text-[#222222] font-semibold leading-relaxed">
                A NEW DIGITAL EXPERIENCE<br />
                IS ON THE WAY.
              </p>
              <p className="text-xs sm:text-[13px] text-[#444444] font-light leading-relaxed font-sans-luxury">
                Same vision. A bolder future.<br />
                Stay tuned for what&apos;s next.
              </p>
            </div>

            {/* Real Interactive Email Subscription Form */}
            <div className="pt-2">
              <EmailSubscriptionForm />
            </div>

            {/* Instagram Link & Category Stack (CLOTHING | CULTURE | COMMUNITY) */}
            <div className="pt-2">
              <InstagramLockup instagramUrl={INSTAGRAM_URL} />
            </div>
          </main>

          {/* ================= BOTTOM SECTION ================= */}
          <footer className="flex items-end justify-between w-full pt-6 border-t border-transparent" id="poster-footer">
            {/* Bottom-Left: KARACHI — WORLDWIDE */}
            <div id="footer-location">
              <p className="text-[8.5px] sm:text-[9.5px] uppercase tracking-[0.26em] text-[#222222] font-medium">
                KARACHI — WORLDWIDE
              </p>
            </div>

            {/* Bottom-Right: Copyright & Accent Rule */}
            <div className="text-right space-y-1.5" id="footer-copyright">
              <div className="w-5 sm:w-6 h-[1.5px] bg-[#111111] ml-auto mb-1.5" aria-hidden="true" />
              <p className="text-[8px] sm:text-[9px] uppercase tracking-[0.22em] text-[#444444] font-light leading-tight">
                © 2026 RYVORA.
              </p>
              <p className="text-[8px] sm:text-[9px] uppercase tracking-[0.22em] text-[#444444] font-light leading-tight">
                ALL RIGHTS RESERVED.
              </p>
            </div>
          </footer>

        </div>
      </div>
    </div>
  );
}
