import React, { useState } from 'react';
import { Subscriber, SiteConfig } from '../types';
import { exportSubscribersToCSV, removeSubscriber, saveStoredConfig, markSubscribersNotified } from '../data/storage';
import { X, Download, Trash2, Mail, ExternalLink, Send, CheckCircle2, ShieldCheck, Sparkles } from 'lucide-react';

interface AdminDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  subscribers: Subscriber[];
  onSubscribersChange: () => void;
  config: SiteConfig;
  onConfigChange: (newConfig: SiteConfig) => void;
  onOpenLaunchPreview: () => void;
  onOpenGitHubGuide: () => void;
}

export const AdminDrawer: React.FC<AdminDrawerProps> = ({
  isOpen,
  onClose,
  subscribers,
  onSubscribersChange,
  config,
  onConfigChange,
  onOpenLaunchPreview,
  onOpenGitHubGuide,
}) => {
  const [formspreeInput, setFormspreeInput] = useState(config.formspreeEndpoint || '');
  const [saveMessage, setSaveMessage] = useState('');
  const [launchDispatched, setLaunchDispatched] = useState(false);

  if (!isOpen) return null;

  const handleSaveFormspree = (e: React.FormEvent) => {
    e.preventDefault();
    const updated = saveStoredConfig({ formspreeEndpoint: formspreeInput.trim() });
    onConfigChange(updated);
    setSaveMessage('Settings saved! Submissions will forward to your endpoint.');
    setTimeout(() => setSaveMessage(''), 3000);
  };

  const handleDelete = (id: string) => {
    removeSubscriber(id);
    onSubscribersChange();
  };

  const handleSimulateLaunchNotification = () => {
    markSubscribersNotified();
    onSubscribersChange();
    setLaunchDispatched(true);
    setTimeout(() => setLaunchDispatched(false), 4000);
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/40 backdrop-blur-xs transition-opacity duration-300">
      <div
        className="w-full max-w-lg bg-[#FAF8F5] h-full shadow-2xl flex flex-col border-l border-[#E5E0D8] text-[#111111]"
        id="admin-subscribers-drawer"
      >
        {/* Header */}
        <div className="p-6 border-b border-[#E5E0D8] flex items-center justify-between bg-white/70">
          <div>
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-600 animate-pulse" />
              <h2 className="text-sm uppercase tracking-[0.2em] font-sans-luxury font-semibold text-[#111111]">
                Ryvora Launch Hub
              </h2>
            </div>
            <p className="text-xs text-[#666666] mt-0.5">
              Live Subscriber Database & Launch Email Center
            </p>
          </div>
          <button
            onClick={onClose}
            aria-label="Close Launch Hub"
            className="p-1.5 hover:bg-[#EFECE6] rounded text-[#444444] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Quick Metrics Bar */}
          <div className="grid grid-cols-2 gap-3">
            <div className="p-4 bg-white border border-[#E5E0D8] rounded-sm">
              <span className="text-[10px] uppercase tracking-wider text-[#666666] block">
                Total Subscribers
              </span>
              <span className="text-2xl font-serif-luxury font-semibold text-[#111111] mt-1 block">
                {subscribers.length}
              </span>
            </div>
            <div className="p-4 bg-white border border-[#E5E0D8] rounded-sm">
              <span className="text-[10px] uppercase tracking-wider text-[#666666] block">
                Launch Status
              </span>
              <span className="text-xs font-sans-luxury font-medium text-emerald-800 mt-2 block flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4" /> Ready to Notify
              </span>
            </div>
          </div>

          {/* Action Row */}
          <div className="flex flex-wrap gap-2">
            <button
              onClick={() => exportSubscribersToCSV(subscribers)}
              disabled={subscribers.length === 0}
              className="flex-1 flex items-center justify-center gap-2 px-3 py-2.5 bg-[#111111] text-white text-xs tracking-wider uppercase font-medium hover:bg-black transition-colors disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              Export CSV
            </button>
            <button
              onClick={onOpenLaunchPreview}
              className="flex items-center justify-center gap-1.5 px-3 py-2.5 border border-[#111111] bg-white text-[#111111] text-xs tracking-wider uppercase font-medium hover:bg-[#F2EFEB] transition-colors cursor-pointer"
            >
              <Mail className="w-3.5 h-3.5" />
              Preview Launch Email
            </button>
          </div>

          {/* Launch Email Dispatch Simulator */}
          <div className="p-4 bg-white border border-[#E5E0D8] rounded-sm space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-semibold uppercase tracking-wider text-[#111111] flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-amber-600" />
                Notify All Subscribers
              </h3>
              <span className="text-[10px] text-[#777777]">One-click notification</span>
            </div>
            <p className="text-xs text-[#555555] leading-relaxed">
              When your website is ready to launch, broadcast the official launch invitation to all{' '}
              <strong>{subscribers.length}</strong> VIP subscribers on your list.
            </p>

            {launchDispatched && (
              <div className="p-2.5 bg-emerald-50 border border-emerald-300 text-emerald-800 text-xs flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>Launch notification dispatched to all subscribers!</span>
              </div>
            )}

            <button
              onClick={handleSimulateLaunchNotification}
              disabled={subscribers.length === 0}
              className="w-full flex items-center justify-center gap-2 py-2 px-3 bg-[#2D2A26] hover:bg-[#111111] text-white text-xs uppercase tracking-wider transition-colors disabled:opacity-40 cursor-pointer"
            >
              <Send className="w-3.5 h-3.5" />
              Send Launch Announcement to All ({subscribers.length})
            </button>
          </div>

          {/* Free Email Forwarding Setup (Formspree / GitHub) */}
          <div className="p-4 bg-white border border-[#E5E0D8] rounded-sm space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-semibold uppercase tracking-wider text-[#111111]">
                Receive Submissions in Real Inbox
              </h3>
              <button
                onClick={onOpenGitHubGuide}
                className="text-[11px] text-neutral-600 underline hover:text-black flex items-center gap-1"
              >
                GitHub Guide <ExternalLink className="w-3 h-3" />
              </button>
            </div>
            <p className="text-xs text-[#555555] leading-relaxed">
              On GitHub Pages or your custom domain (<code>ryvora.pk</code>), connect a free endpoint
              like <strong>Formspree</strong> so every new subscriber is emailed directly to your inbox.
            </p>

            <form onSubmit={handleSaveFormspree} className="space-y-2">
              <input
                type="text"
                value={formspreeInput}
                onChange={(e) => setFormspreeInput(e.target.value)}
                placeholder="https://formspree.io/f/your_form_id"
                className="w-full text-xs px-3 py-2 bg-[#FAF8F5] border border-[#CCCCCC] focus:border-black focus:outline-none"
              />
              <div className="flex items-center justify-between">
                <button
                  type="submit"
                  className="px-3 py-1.5 bg-[#111111] text-white text-[11px] uppercase tracking-wider hover:bg-black transition-colors"
                >
                  Save Endpoint
                </button>
                {saveMessage && (
                  <span className="text-[11px] text-emerald-700 font-medium">{saveMessage}</span>
                )}
              </div>
            </form>
          </div>

          {/* Subscriber Table / List */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-semibold uppercase tracking-wider text-[#111111]">
                Subscribers ({subscribers.length})
              </h3>
              <span className="text-[10px] text-[#777777]">Live persistent store</span>
            </div>

            {subscribers.length === 0 ? (
              <div className="p-8 text-center bg-white border border-dashed border-[#D6D0C7] text-[#888888] text-xs">
                No email signups yet. Enter an email on the main page to test!
              </div>
            ) : (
              <div className="divide-y divide-[#E5E0D8] border border-[#E5E0D8] bg-white rounded-sm max-h-[300px] overflow-y-auto">
                {subscribers.map((sub) => (
                  <div
                    key={sub.id}
                    className="p-3 flex items-center justify-between hover:bg-[#F9F7F4] text-xs transition-colors"
                  >
                    <div className="min-w-0 pr-2">
                      <p className="font-medium text-[#111111] truncate">{sub.email}</p>
                      <div className="flex items-center gap-2 mt-0.5 text-[10px] text-[#777777]">
                        <span>{new Date(sub.createdAt).toLocaleDateString()}</span>
                        <span>•</span>
                        <span className={sub.notified ? 'text-emerald-700 font-medium' : 'text-amber-700'}>
                          {sub.notified ? 'Notified of launch' : 'Awaiting launch'}
                        </span>
                      </div>
                    </div>
                    <button
                      onClick={() => handleDelete(sub.id)}
                      aria-label={`Remove ${sub.email}`}
                      className="text-[#999999] hover:text-red-600 p-1 transition-colors"
                      title="Delete"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
