import React from 'react';
import { Instagram } from 'lucide-react';

interface InstagramLockupProps {
  instagramUrl: string;
}

export const InstagramLockup: React.FC<InstagramLockupProps> = ({ instagramUrl }) => {
  return (
    <div className="flex items-center gap-3.5 sm:gap-4 text-[#111111]" id="social-category-lockup">
      {/* Instagram Camera Icon Link */}
      <a
        id="link-instagram"
        href={instagramUrl}
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Visit Ryvora on Instagram"
        title="Visit Ryvora on Instagram (@ryvora.pk)"
        className="p-1 -ml-1 text-[#111111] hover:opacity-60 transition-opacity duration-200 focus:outline-none focus:ring-1 focus:ring-black cursor-pointer group"
      >
        <Instagram className="w-6 h-6 sm:w-[26px] sm:h-[26px] stroke-[1.65] group-hover:scale-105 transition-transform" />
      </a>

      {/* Vertical Hairline Divider matching poster */}
      <div className="w-[1px] h-9 bg-[#111111] select-none" aria-hidden="true" />

      {/* CLOTHING / CULTURE / COMMUNITY Stack */}
      <div className="text-[8px] sm:text-[9px] tracking-[0.24em] font-sans-luxury font-medium text-[#111111] leading-[1.35] uppercase select-none">
        <p>CLOTHING</p>
        <p>CULTURE</p>
        <p>COMMUNITY</p>
      </div>
    </div>
  );
};
