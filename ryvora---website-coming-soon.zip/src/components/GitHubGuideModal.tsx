import React, { useState } from 'react';
import { X, Copy, Check, ExternalLink, Github, Mail, Globe, Code2 } from 'lucide-react';

interface GitHubGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
  instagramUrl: string;
}

export const GitHubGuideModal: React.FC<GitHubGuideModalProps> = ({
  isOpen,
  onClose,
  instagramUrl,
}) => {
  const [copiedSection, setCopiedSection] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedSection(id);
    setTimeout(() => setCopiedSection(null), 2000);
  };

  const pureHtmlCode = `<!-- RYVORA Coming Soon Form - Formspree Free Endpoint -->
<form action="https://formspree.io/f/YOUR_FORMSPREE_ID" method="POST" class="email-form">
  <input 
    type="email" 
    name="email" 
    placeholder="Enter your email" 
    required 
    class="email-input" 
  />
  <button type="submit" aria-label="Subscribe" class="submit-btn">→</button>
</form>

<!-- Working Instagram Link -->
<a href="${instagramUrl}" target="_blank" rel="noopener noreferrer" aria-label="Instagram">
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
    <rect x="2" y="2" width="20" height="20" rx="5" ry="5"></rect>
    <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path>
    <line x1="17.5" y1="6.5" x2="17.51" y2="6.5"></line>
  </svg>
</a>`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
      <div
        className="w-full max-w-2xl bg-[#FAF8F5] max-h-[90vh] flex flex-col shadow-2xl border border-[#DCD6CC] text-[#111111] overflow-hidden"
        id="github-guide-modal"
      >
        {/* Header */}
        <div className="p-5 sm:p-6 border-b border-[#E5E0D8] flex items-center justify-between bg-white">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-[#111111] text-white rounded">
              <Github className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm sm:text-base uppercase tracking-[0.18em] font-sans-luxury font-semibold text-[#111111]">
                GitHub & Live Website Setup
              </h2>
              <p className="text-xs text-[#666666]">
                How to launch this exact page on your website with working email & Instagram
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            aria-label="Close Guide"
            className="p-1.5 hover:bg-[#EFECE6] rounded text-[#555555] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable instructions */}
        <div className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-6 text-xs sm:text-[13px] leading-relaxed">
          {/* Question 1: Do I need any code / HTCL? */}
          <div className="p-4 bg-white border border-[#E5E0D8] rounded-sm space-y-2">
            <h3 className="font-semibold text-sm text-[#111111] flex items-center gap-2">
              <Code2 className="w-4 h-4 text-[#111111]" />
              1. Do you need any code or HTML?
            </h3>
            <p className="text-[#444444]">
              <strong>No manual coding is required!</strong> This application is completely built with
              modern React, Tailwind CSS, and HTML. Everything in your poster—the luxury typography,
              stone background, working email form, and working social icons—is already coded and ready
              to export.
            </p>
          </div>

          {/* Question 2: How the Instagram icon works */}
          <div className="p-4 bg-white border border-[#E5E0D8] rounded-sm space-y-2">
            <h3 className="font-semibold text-sm text-[#111111] flex items-center gap-2">
              <Globe className="w-4 h-4 text-emerald-800" />
              2. How the Instagram Link Works
            </h3>
            <p className="text-[#444444]">
              Your Instagram link is configured directly to:
            </p>
            <div className="p-2.5 bg-[#F4F1EA] font-mono text-[11px] text-[#222222] break-all border border-[#E0DBD2] flex items-center justify-between">
              <span>{instagramUrl}</span>
              <a
                href={instagramUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="ml-2 px-2 py-1 bg-[#111111] text-white text-[10px] uppercase font-sans hover:bg-black shrink-0 flex items-center gap-1"
              >
                Test Link <ExternalLink className="w-3 h-3" />
              </a>
            </div>
            <p className="text-[#666666] text-[12px]">
              When visitors click the Instagram camera icon on your live website, it immediately opens
              your official <code>@ryvora.pk</code> profile in a new tab.
            </p>
          </div>

          {/* Question 3: How to receive email data on GitHub Pages */}
          <div className="p-4 bg-white border border-[#E5E0D8] rounded-sm space-y-3">
            <h3 className="font-semibold text-sm text-[#111111] flex items-center gap-2">
              <Mail className="w-4 h-4 text-amber-700" />
              3. How to Receive Real Email Submissions from GitHub
            </h3>
            <p className="text-[#444444]">
              GitHub Pages hosts static websites (it does not run a private database server). To receive
              subscribers directly into your personal email inbox:
            </p>
            <ol className="list-decimal list-inside space-y-2 text-[#444444] pl-1">
              <li>
                Go to <a href="https://formspree.io" target="_blank" rel="noopener noreferrer" className="underline font-medium text-black">Formspree.io</a> (free, takes 1 minute).
              </li>
              <li>
                Click <strong>"New Form"</strong> and name it <em>Ryvora Coming Soon</em>.
              </li>
              <li>
                Copy your Formspree Form ID (e.g. <code>https://formspree.io/f/xvgkqowp</code>).
              </li>
              <li>
                Paste that URL into the <strong>Launch Hub Drawer</strong> in this app, or in the code.
                Whenever someone enters their email and clicks <code>→</code>, Formspree instantly delivers
                their email straight to your Gmail/inbox!
              </li>
            </ol>

            {/* Code Snippet */}
            <div className="relative mt-2">
              <div className="flex items-center justify-between bg-[#222222] text-[#E0E0E0] px-3 py-1.5 text-[11px] font-mono">
                <span>Direct HTML Snippet for Formspree & Instagram</span>
                <button
                  onClick={() => handleCopy(pureHtmlCode, 'html-snippet')}
                  className="flex items-center gap-1 hover:text-white transition-colors"
                >
                  {copiedSection === 'html-snippet' ? (
                    <>
                      <Check className="w-3 h-3 text-emerald-400" /> Copied
                    </>
                  ) : (
                    <>
                      <Copy className="w-3 h-3" /> Copy Snippet
                    </>
                  )}
                </button>
              </div>
              <pre className="p-3 bg-[#181818] text-[#D4D4D4] font-mono text-[11px] overflow-x-auto border-t border-neutral-700">
                {pureHtmlCode}
              </pre>
            </div>
          </div>

          {/* Question 4: Uploading to GitHub & Connecting Domain */}
          <div className="p-4 bg-white border border-[#E5E0D8] rounded-sm space-y-3">
            <h3 className="font-semibold text-sm text-[#111111] flex items-center gap-2">
              <Github className="w-4 h-4 text-[#111111]" />
              4. Adding into GitHub and Connecting to your Website (ryvora.pk)
            </h3>
            <div className="space-y-2 text-[#444444]">
              <p>
                <strong>Step 1: Export project</strong><br />
                In AI Studio's top-right settings menu, click <strong>"Export to GitHub"</strong> or <strong>"Download ZIP"</strong>.
              </p>
              <p>
                <strong>Step 2: Connect to your custom domain (ryvora.pk)</strong><br />
                You can host it completely free on either <strong>GitHub Pages</strong> or <strong>Vercel</strong>:
              </p>
              <ul className="list-disc list-inside pl-2 space-y-1 text-[12px] text-[#555555]">
                <li><strong>Recommended (easiest): Vercel / Netlify</strong> — Import your GitHub repository. It automatically compiles and offers a 1-click custom domain setting for <code>ryvora.pk</code> with free SSL.</li>
                <li><strong>GitHub Pages</strong> — In your GitHub repository, go to <em>Settings → Pages → Source</em>, choose <em>GitHub Actions (Static HTML/Vite)</em>, and in the Custom domain box enter <code>ryvora.pk</code>.</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-[#E5E0D8] bg-[#F4F1EA] flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 bg-[#111111] text-white text-xs uppercase tracking-wider hover:bg-black transition-colors"
          >
            Got it, return to preview
          </button>
        </div>
      </div>
    </div>
  );
};
