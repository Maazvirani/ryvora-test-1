import React, { useState } from 'react';
import { ArrowRight, Check, Loader2, AlertCircle } from 'lucide-react';
import { addSubscriber } from '../data/storage';

interface EmailSubscriptionFormProps {
  onSubscriberAdded?: () => void;
}

export const EmailSubscriptionForm: React.FC<EmailSubscriptionFormProps> = ({
  onSubscriberAdded,
}) => {
  const [email, setEmail] = useState('');
  const [status, setStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');
  const [feedbackMessage, setFeedbackMessage] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || status === 'loading') return;

    setStatus('loading');
    setFeedbackMessage('');

    try {
      await new Promise((res) => setTimeout(res, 350));
      const result = await addSubscriber(email);

      if (result.success) {
        setStatus('success');
        setFeedbackMessage(result.message);
        setEmail('');
        if (onSubscriberAdded) {
          onSubscriberAdded();
        }
      } else {
        setStatus('error');
        setFeedbackMessage(result.message);
      }
    } catch {
      setStatus('error');
      setFeedbackMessage('Something went wrong. Please try again.');
    }
  };

  return (
    <div className="w-full max-w-[380px] sm:max-w-[420px]" id="email-subscription-section">
      <form onSubmit={handleSubmit} className="relative" id="newsletter-form">
        {/* Form Container with outline and solid black button */}
        <div
          className={`flex items-stretch border transition-colors duration-200 bg-[#FAF8F5]/85 backdrop-blur-xs ${
            status === 'error'
              ? 'border-red-600'
              : status === 'success'
              ? 'border-emerald-800'
              : 'border-[#111111]'
          }`}
        >
          {/* Email input field */}
          <input
            id="email-input-field"
            type="email"
            value={email}
            onChange={(e) => {
              setEmail(e.target.value);
              if (status !== 'idle') {
                setStatus('idle');
                setFeedbackMessage('');
              }
            }}
            placeholder="Enter your email"
            aria-label="Enter your email"
            required
            disabled={status === 'loading'}
            className="w-full bg-transparent px-3.5 sm:px-4 py-2.5 sm:py-3 text-xs sm:text-[13.5px] font-sans-luxury text-[#111111] placeholder:text-[#555555] placeholder:font-light tracking-wide focus:outline-none disabled:opacity-50"
          />

          {/* Solid Black Submit Arrow Button matching poster */}
          <button
            id="email-submit-button"
            type="submit"
            disabled={status === 'loading'}
            aria-label="Submit email for launch notification"
            className="bg-[#111111] text-white px-4 sm:px-5 flex items-center justify-center hover:bg-black active:bg-neutral-900 transition-colors duration-200 disabled:opacity-50 cursor-pointer shrink-0"
          >
            {status === 'loading' ? (
              <Loader2 className="w-4 h-4 animate-spin text-white" />
            ) : status === 'success' ? (
              <Check className="w-4 h-4 text-emerald-300" />
            ) : (
              <ArrowRight className="w-4 h-4 stroke-[1.5] text-white" />
            )}
          </button>
        </div>

        {/* Subtitle label matching poster */}
        <p className="mt-2.5 text-[8.5px] sm:text-[9.5px] uppercase tracking-[0.28em] text-[#222222] font-sans-luxury font-medium select-none">
          BE THE FIRST TO KNOW
        </p>

        {/* Live Feedback Toast Notification */}
        {feedbackMessage && (
          <div
            id="subscription-feedback"
            className={`mt-2.5 text-[11px] tracking-wide p-2 transition-all duration-300 flex items-start gap-1.5 ${
              status === 'success'
                ? 'bg-emerald-50/95 text-emerald-950 border border-emerald-300'
                : 'bg-red-50/95 text-red-950 border border-red-300'
            }`}
          >
            {status === 'success' ? (
              <Check className="w-3.5 h-3.5 mt-0.5 shrink-0 text-emerald-700" />
            ) : (
              <AlertCircle className="w-3.5 h-3.5 mt-0.5 shrink-0 text-red-700" />
            )}
            <span className="font-light leading-snug">{feedbackMessage}</span>
          </div>
        )}
      </form>
    </div>
  );
};
