import React from 'react';
import { X, Mail, Send, CheckCircle2, ArrowRight } from 'lucide-react';
import { Subscriber } from '../types';

interface LaunchPreviewModalProps {
  isOpen: boolean;
  onClose: () => void;
  subscribers: Subscriber[];
  onDispatchSimulated: () => void;
  instagramUrl: string;
}

export const LaunchPreviewModal: React.FC<LaunchPreviewModalProps> = ({
  isOpen,
  onClose,
  subscribers,
  onDispatchSimulated,
  instagramUrl,
}) => {
  const [sent, setSent] = React.useState(false);

  if (!isOpen) return null;

  const handleSend = () => {
    onDispatchSimulated();
    setSent(true);
    setTimeout(() => {
      setSent(false);
      onClose();
    }, 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
      <div
        className="w-full max-w-xl bg-white max-h-[90vh] flex flex-col shadow-2xl border border-[#E0D9CE] text-[#111111] overflow-hidden"
        id="launch-email-preview-modal"
      >
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-[#E5E0D8] flex items-center justify-between bg-[#F8F6F2]">
          <div className="flex items-center gap-2">
            <Mail className="w-4 h-4 text-[#111111]" />
            <h2 className="text-xs sm:text-sm uppercase tracking-[0.2em] font-sans-luxury font-semibold text-[#111111]">
              Subscriber Launch Email Preview
            </h2>
          </div>
          <button
            onClick={onClose}
            aria-label="Close Preview"
            className="p-1 hover:bg-[#EAE5DC] rounded text-[#555555] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Mock Email Client Container */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 bg-[#F3EFEA]/60">
          <div className="bg-white border border-[#E0DCD5] shadow-xs max-w-md mx-auto p-6 sm:p-8 space-y-6">
            {/* Metadata headers */}
            <div className="border-b border-[#EBE7E0] pb-4 space-y-1.5 text-xs text-[#555555]">
              <div className="flex justify-between">
                <span className="text-[#888888]">From:</span>
                <span className="font-medium text-[#111111]">Ryvora Concierge &lt;access@ryvora.pk&gt;</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#888888]">To:</span>
                <span className="italic text-[#111111]">
                  {subscribers.length > 0 ? subscribers[0].email : 'vip.subscriber@example.com'} (and {Math.max(0, subscribers.length - 1)} others)
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#888888]">Subject:</span>
                <span className="font-serif-luxury font-semibold text-[#111111]">
                  Private Access: The Ryvora Digital Flagship is Now Live
                </span>
              </div>
            </div>

            {/* Email Body matching Ryvora Brand */}
            <div className="text-center space-y-5 pt-2">
              <div className="space-y-1">
                <h1 className="text-lg tracking-[0.3em] font-serif-luxury font-bold text-[#111111]">
                  R Y V O R A
                </h1>
                <p className="text-[9px] uppercase tracking-[0.25em] text-[#666666]">
                  B E Y O N D   B A S I C S
                </p>
                <div className="w-8 h-[1px] bg-[#111111] mx-auto mt-2" />
              </div>

              <div className="py-2">
                <p className="text-[10px] uppercase tracking-[0.2em] text-[#888888] font-sans-luxury">
                  THE WAIT IS OVER
                </p>
                <h2 className="text-xl sm:text-2xl font-serif-luxury text-[#111111] mt-1 font-normal leading-tight">
                  Our Digital Flagship is Officially Open
                </h2>
              </div>

              <p className="text-xs text-[#444444] leading-relaxed max-w-sm mx-auto font-light">
                Thank you for reserving your place in our inaugural community. As promised, you are among the first to experience Ryvora’s new digital world and explore our initial collection.
              </p>

              <div className="p-4 bg-[#FAF8F5] border border-[#E7E2D8] text-center max-w-xs mx-auto">
                <span className="text-[10px] uppercase tracking-wider text-[#777777] block">
                  VIP Early Access Code
                </span>
                <span className="text-sm font-mono tracking-widest font-semibold text-[#111111] mt-1 block">
                  FIRST-ACCESS-RYVORA
                </span>
              </div>

              <div className="pt-2">
                <a
                  href="/"
                  onClick={(e) => e.preventDefault()}
                  className="inline-flex items-center gap-2 px-6 py-3 bg-[#111111] text-white text-xs uppercase tracking-[0.2em] font-medium hover:bg-black transition-colors"
                >
                  Enter The Flagship <ArrowRight className="w-3.5 h-3.5" />
                </a>
              </div>

              <div className="pt-4 border-t border-[#EFECE6] text-[10px] text-[#777777] space-y-1">
                <p>Follow along on Instagram: <a href={instagramUrl} target="_blank" rel="noopener noreferrer" className="underline text-black">@ryvora.pk</a></p>
                <p>© 2026 Ryvora. All rights reserved.</p>
              </div>
            </div>
          </div>
        </div>

        {/* Footer actions */}
        <div className="p-4 border-t border-[#E5E0D8] bg-[#F8F6F2] flex items-center justify-between">
          <span className="text-xs text-[#666666]">
            Queue: <strong>{subscribers.length}</strong> recipient{subscribers.length === 1 ? '' : 's'}
          </span>
          <div className="flex gap-2">
            <button
              onClick={onClose}
              className="px-4 py-2 text-xs uppercase tracking-wider text-[#555555] hover:text-black transition-colors"
            >
              Close
            </button>
            <button
              onClick={handleSend}
              disabled={subscribers.length === 0 || sent}
              className="flex items-center gap-1.5 px-4 py-2 bg-[#111111] text-white text-xs uppercase tracking-wider font-medium hover:bg-black transition-colors disabled:opacity-40 cursor-pointer"
            >
              {sent ? (
                <>
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> Dispatched!
                </>
              ) : (
                <>
                  <Send className="w-3.5 h-3.5" /> Test Dispatch
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
