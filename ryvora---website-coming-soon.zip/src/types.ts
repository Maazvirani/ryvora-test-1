export interface Subscriber {
  id: string;
  email: string;
  createdAt: string;
  source?: string;
  notified?: boolean;
}

export interface SiteConfig {
  instagramUrl: string;
  tiktokUrl: string;
  youtubeUrl: string;
  formspreeEndpoint: string; // e.g. https://formspree.io/f/xyz
  ownerEmailNotification: string;
  brandName: string;
  launchDateEstimated: string;
}
